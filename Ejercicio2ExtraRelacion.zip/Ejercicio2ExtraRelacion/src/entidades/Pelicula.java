package entidades;

public class Pelicula {
    private String title;
    private int duration;
    private int minAge;
    private String Director;

    public Pelicula(String title, int duration, int minAge, String director) {
        this.title = title;
        this.duration = duration;
        this.minAge = minAge;
        Director = director;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public int getMinAge() {
        return minAge;
    }

    public void setMinAge(int minAge) {
        this.minAge = minAge;
    }

    public String getDirector() {
        return Director;
    }

    public void setDirector(String director) {
        Director = director;
    }

    @Override
    public String toString() {
        return "Pelicula{" +
                "Título='" + title + '\'' +
                ", duración=" + duration +
                ", Edad mínima=" + minAge +
                ", Director='" + Director + '\'' +
                '}';
    }
}
