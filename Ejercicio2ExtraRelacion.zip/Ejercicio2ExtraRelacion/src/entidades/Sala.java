package entidades;

import java.util.Arrays;

public class Sala {

    private Asiento[][] asientos;
    private char[] letras;

    public Sala() {
        this.asientos = new Asiento[8][6];
        this.letras = new char[]{'A', 'B', 'C', 'D', 'E', 'F'};
    }

    public Asiento[][] getAsientos() {
        return asientos;
    }

    public void setAsientos(Asiento[][] asientos) {
        this.asientos = asientos;
    }

    public char[] getLetras() {
        return letras;
    }

    public void setLetras(char[] letras) {
        this.letras = letras;
    }

    @Override
    public String toString() {
        return "Sala{" +
                "asientos=" + Arrays.toString(asientos) +
                ", letras=" + Arrays.toString(letras) +
                '}';
    }
}
