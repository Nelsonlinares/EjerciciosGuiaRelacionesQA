package entidades;

public class Asiento {
    private int fila;
    private char columna;
    private String marcaOcupado;
    private boolean ocupado;
    private Espectador espectador;

    public Asiento(int fila, char columna) {
        this.fila = fila;
        this.columna = columna;
        this.ocupado = false;
        this.marcaOcupado = " ";
    }

    public Asiento() {
    }

    public int getFila() {
        return fila;
    }

    public void setFila(int fila) {
        this.fila = fila;
    }

    public char getColumna() {
        return columna;
    }

    public void setColumna(char columna) {
        this.columna = columna;
    }

    public String getMarcaOcupado() {
        return marcaOcupado;
    }

    public void setMarcaOcupado(String marcaOcupado) {
        this.marcaOcupado = marcaOcupado;
    }

    public boolean isOcupado() {
        return ocupado;
    }

    public void setOcupado(boolean ocupado) {
        this.ocupado = ocupado;
    }

    public Espectador getEspectador() {
        return espectador;
    }

    public void setEspectador(Espectador espectador) {
        this.espectador = espectador;
    }
}
