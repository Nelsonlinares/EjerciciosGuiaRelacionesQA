package services;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import entidades.Asiento;
import entidades.Espectador;
import entidades.Pelicula;
import entidades.Sala;

public class Cine {
    private Pelicula pelicula;
    private double entryPrice;
    private List<Espectador> espectadores;
    private Sala sala;

    public Cine() {
        this.sala = new Sala();
        this.entryPrice = 125;
        this.espectadores = new ArrayList<>();
        this.pelicula = new Pelicula("Oppenheimer", 180, 15, "Nolan");
    }
    
    public void mostrarPelicula(){
        System.out.println("La funci�n del cine es:");
        System.out.println(pelicula);
    }

    public void llenarExpectadores() {
        espectadores.add(new Espectador("Rolando", 21, 250));
        espectadores.add(new Espectador("Nelson", 30, 120));
        espectadores.add(new Espectador("Cristian", 17, 150));
        espectadores.add(new Espectador("Diana", 20, 100));
        espectadores.add(new Espectador("Nicolas", 15, 200));
        espectadores.add(new Espectador("Alonso", 12, 175));
        espectadores.add(new Espectador("Marcela", 18, 50));
    }
    
    public boolean aceptarEspectador(Espectador esp, Asiento as){
        if (esp.getMoney()>entryPrice){
            if(esp.getAge()>=pelicula.getMinAge()){
                if(!as.isOcupado()){
                    return true;
                }else{
                    System.err.println("El asiento se encuentra ocupado");
                }
            }else{
                System.err.printf("%s No tiene la edad m�nima para ver la pelicula.\n",esp.getName());
            }
        }else {
            System.err.printf("%s no tiene suficiente dinero.\n",esp.getName());
        }
        return false;
    }

    public void ubicarEspectador(){
        Random random = new Random();
        for(Espectador e : espectadores){
            int fila = random.nextInt(8);
            int columna = random.nextInt(6);
            Asiento asiento = sala.getAsientos()[fila][columna];
            if(aceptarEspectador(e, asiento)){
                    asiento.setEspectador(e);
                    asiento.setMarcaOcupado("X");
            }
        }
        System.out.println("Se han asignado asiento a los espectadores");
    }

    public void crearSalaDeCine(){
        Asiento[][] asientos = new Asiento[8][6];
        for(int i = 0; i <8; i++) {
          for(int j = 0; j <6; j++) {
              asientos[i][j] = new Asiento(i+1,sala.getLetras()[j]);
        }
        }
        sala.setAsientos(asientos);
    }

    public void mostrarSala(){
        for(int i = 7; i >=0; i--) {
          for(int j = 0; j < 6; j++) {
              int fila = sala.getAsientos()[i][j].getFila();
              char columna = sala.getAsientos()[i][j].getColumna();
              String ocupado = sala.getAsientos()[i][j].getMarcaOcupado();

              System.out.printf("|%d %c %s|",fila,columna, ocupado);
        }
            System.out.println();
        }
    }
}
