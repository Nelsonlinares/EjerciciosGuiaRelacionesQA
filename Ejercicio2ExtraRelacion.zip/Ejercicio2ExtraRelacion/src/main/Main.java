package main;

import services.Cine;

public class Main {

	public static void main(String[] args) {
		Cine cine = new Cine();
		
		cine.crearSalaDeCine();
        cine.llenarExpectadores();
        cine.mostrarPelicula();
        cine.ubicarEspectador();
        cine.mostrarSala();

	}

}
