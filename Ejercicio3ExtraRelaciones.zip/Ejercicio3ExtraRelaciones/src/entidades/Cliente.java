package entidades;

public class Cliente {
	private String nombre;
	private String apellido;
	private String documento;
	private String mail;
	private String domicilio;
	private int telefono;
}
