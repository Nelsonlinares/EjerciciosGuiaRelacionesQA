package entidades;

import java.time.LocalDate;
import java.util.List;

public class Poliza {
	
	private Cliente cliente;
	private Vehiculo vehiculo;
	private int numeroPoliza;
	private LocalDate fechaInicio;
	private LocalDate fechaFin;
	private List<Cuota> cuotas;
	private String formaPago;
	private double montoTotalAsegurado;
	private boolean granizo;
	private double montoMaximoGranizo;
	private String tipoCobertura;
	
}
