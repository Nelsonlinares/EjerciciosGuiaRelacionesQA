package entidades;

import java.awt.Color;

public class Vehiculo {
	private String marca;
	private String modelo;
	private int anio;
	private int numeroMotor;
	private String chasis;
	private Color color;
	private String tipo;
}
