package main;

import java.util.List;

import entidades.Voto;
import service.Simulador;

public class Main {

	public static void main(String[] args) {
		Simulador simulador = new Simulador();
		List<Voto> listaVoto = simulador.crearAlumnos(simulador.generarNombresAleatorios(5),simulador.generarDniAleatorios(5));
		System.out.println(simulador.generarNombresAleatorios(5));
		System.out.println(simulador.generarDniAleatorios(5));
		System.out.println(simulador.crearAlumnos(simulador.generarNombresAleatorios(5),simulador.generarDniAleatorios(5)));
		System.out.println(simulador.votacion(listaVoto);
		
	}

}
