package service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import entidades.Alumno;
import entidades.Voto;

public class Simulador {
		    
    public List<String> generarNombresAleatorios(int cantidad) {
    	
    	List<String> nombres = Arrays.asList("Juan", "Ana", "Pedro", "Luisa","Jes�s");
        List<String> apellidos = Arrays.asList("P�rez", "G�mez", "Rodr�guez", "Gonz�les","Morales");
    
        List<String> listaNombres = new ArrayList<>();
        Random rand = new Random();
        
        // Ac� se concatenan los nombres y los apellidos de las listas anteriores en un solo valor para la 
        // lista que se retorna en el m�todo 
        
        for (int i = 0; i < cantidad; i++) {
            String nombre = nombres.get(rand.nextInt(nombres.size())) + " " + apellidos.get(rand.nextInt(apellidos.size()));
            listaNombres.add(nombre);
        }

        return listaNombres;
    } 
    
    public HashSet<Integer> generarDniAleatorios(int cantidad){
    	HashSet <Integer> dniGenerados = new HashSet<Integer>();
    	Random rand = new Random();
    	while(dniGenerados.size()<cantidad) {
			int dniAleatorio = rand.nextInt(9000)+1000;
			dniGenerados.add(dniAleatorio);
		}
    	
    	return dniGenerados;
    }
    
    public List<Alumno> crearAlumnos(List<String> nombres, HashSet<Integer> dni){
    	ArrayList<Integer> arrayDni = new ArrayList<>(dni);
    	List<Alumno> alumnosCreados = new ArrayList<>();
    	Scanner sc = new Scanner(System.in);
    	System.out.println("Ingrese la cantidad de alumnos que desea crear");
    	int cantidad = sc.nextInt();
    	for (int i = 0; i < cantidad; i++) {
			Alumno alumno = new Alumno(nombres.get(i),arrayDni.get(i));
			alumnosCreados.add(alumno);
		}
    	return alumnosCreados;
    }
    
    public void mostrarAlumnos(List<Alumno> listaAlumnos) {
    	for (Alumno alumno : listaAlumnos) {
			System.out.println(alumno);
		}
    }
    
    public List<Voto> votacion(List<Alumno> alumnos) {
    	List<Voto> listaVotos = new ArrayList<>();
    	
    	for (Alumno alumno : alumnos) {
    		Voto voto = new Voto();
			voto.setAlumno(alumno);
			HashSet<Alumno> votacion = new HashSet<>();
			List<Alumno> auxiliar = alumnos;
			auxiliar.remove(alumno);
			while (votacion.size()<3) {
				Random rand = new Random();
				int indice = rand.nextInt(auxiliar.size());
				votacion.add(alumnos.get(indice));
			}
			voto.setVotados(new ArrayList<>(votacion));
			listaVotos.add(voto);
		}
    	return listaVotos;
    }
    
    public void mostrarVotos(List<Voto> listaVotos) {
    	for (Voto voto : listaVotos) {
			System.out.println(voto);
		}
    }
    
    public void recuentoVotos(List<Voto> listaVotos) {
    	for (Voto voto : listaVotos) {
    		List<Alumno> elegidos = voto.getVotados();
			for (Alumno a : elegidos) {
				a.setCantidadDeVotos(a.getCantidadDeVotos()+1);
			}
		}
    	mostrarVotos(listaVotos);
    }
    
    public void facilitadores(List<Alumno> lista) {
    	
    	for (Alumno alumno : lista) {
			
		}
    }
    
    public void recuentoVotos(ArrayList<Alumno> al){
        Alumno aux = new Alumno();
        al.sort(Alumno.compararCantidad);
        System.out.println(al);
        /*for(int i = 0; i < al.size(); i++){
            for (int j = 0; j < al.size(); j++)
            {
                if(al.get(i).getCantidadDeVotos() > al.get(j).getCantidadDeVotos()){
                    aux = al.get(i);
                    al.set(i, al.get(j));
                    al.set(j, aux);
                }
            }
        }
        
        for (int i = 0; i < 10; i++)
        {
            if(i < 5){
                System.out.println("facilitador "+(i+1)+" es: "+al.get(i).toString());
            }else{
                System.out.println("facilitador suplente "+(i+1-5)+" es: "+al.get(i).toString());
            }
        }
    }*/
}
}
