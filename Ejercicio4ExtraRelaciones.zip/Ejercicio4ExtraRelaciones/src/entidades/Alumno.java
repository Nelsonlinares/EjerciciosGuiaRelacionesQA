package entidades;

import java.util.Comparator;

public class Alumno {

	private String nombreCompleto;
	private int dni;
	private Integer cantidadDeVotos;
	
	
	
	public Alumno() {
		super();
	}

	public Alumno(String nombreCompleto, int dni) {
		super();
		this.nombreCompleto = nombreCompleto;
		this.dni = dni;
		this.cantidadDeVotos = 0;
	}
	
	public String getNombreCompleto() {
		return nombreCompleto;
	}

	public void setNombreCompleto(String nombreCompleto) {
		this.nombreCompleto = nombreCompleto;
	}

	public int getDni() {
		return dni;
	}

	public void setDni(int dni) {
		this.dni = dni;
	}

	public Integer getCantidadDeVotos() {
		return cantidadDeVotos;
	}

	public void setCantidadDeVotos(Integer cantidadDeVotos) {
		this.cantidadDeVotos = cantidadDeVotos;
	}
	
	@Override
	public String toString() {
		return "Alumno [nombreCompleto=" + nombreCompleto + ", dni=" + dni + ", cantidadDeVotos=" + cantidadDeVotos
				+ "]";
	}
	
	public static Comparator<Alumno> compararCantidad = (Alumno a1, Alumno a2) -> a1.getCantidadDeVotos().compareTo(a2.getCantidadDeVotos());
}
